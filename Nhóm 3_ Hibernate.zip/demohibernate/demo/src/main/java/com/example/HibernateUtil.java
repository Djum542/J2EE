package com.example;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
public class HibernateUtil 
{
    public static void main( String[] args )
    {
        try {
        //Create configuration
    	Configuration configuration = new Configuration();
    	configuration.configure("hibernate.cfg.xml");
    	
    	//Create session factory
    	SessionFactory sessionFactory = configuration.buildSessionFactory();
    	
        //Initialize the session object
    	Session session = sessionFactory.openSession();
        KhachHang aHang = new KhachHang();

        // Save Data
        session.getTransaction().begin();

        aHang.setMaKhachHang("KH04");
        aHang.setMatKhau("123123");
        aHang.setHoVaTen("Moo");
        aHang.setEmail("Momo@gmail.com");
        aHang.setDienThoai("098999123");
        
        session.save(aHang);
        
        session.getTransaction().commit();

        // Get Data
        // List<KhachHang> khachHangs = session.createQuery("FROM KhachHang", KhachHang.class).list();
        
        // for (KhachHang khachHang : khachHangs) {
        //     System.out.println(khachHang.getMaKhachHang() + "\t" + khachHang.getMatKhau() + "\t" + khachHang.getHoVaTen() +
        //      "\t" + khachHang.getEmail() + "\t" + khachHang.getDienThoai());
        // }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
