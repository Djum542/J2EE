package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Duration;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class FirstScriptTest {

    @Test
    public void eightComponents() {
        // Bắt đầu phiên trình điều khiển
        WebDriver driver = new EdgeDriver();
        // Thực hiện hành động trên trình duyệt ở đây ta đặt một đia chỉ trang web
        driver.get("https://www.selenium.dev/selenium/web/web-form.html");
        // Yêu cầu thông tin trình duyệt
        String title = driver.getTitle();
        assertEquals("Web form", title);
        // Thiết lập chiến lược chờ đợi
        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(500));
        // Tìm một phần tử
        WebElement textBox = driver.findElement(By.name("my-text"));
        WebElement submitButton = driver.findElement(By.cssSelector("button"));
        // Thực hiện hành động trên phần tử.
        textBox.sendKeys("Selenium");
        submitButton.click();

        WebElement message = driver.findElement(By.id("message"));
        // Yêu cầu thông tin phần tử
        String value = message.getText();
        assertEquals("Received!", value);
        // kết thúc phiên
        driver.quit();
    }

}

